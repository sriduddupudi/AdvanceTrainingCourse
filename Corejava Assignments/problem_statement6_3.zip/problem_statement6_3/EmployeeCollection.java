package com.problem_statement6_3;
	import java.util.Vector;

	public class EmployeeCollection{
	public static void main(String[] args) {
		Vector<EmployeeClass> v = addInput();
		display(v);
	}

	private static Vector<EmployeeClass> addInput() {
		// TODO Auto-generated method stub
		EmployeeClass e1 = new EmployeeClass(111,"Srinivas","Nallajerla") ;
		EmployeeClass e2 = new EmployeeClass(222,"Shabbir","Pangidi") ;
		EmployeeClass e3 = new EmployeeClass(333,"Sriram","Chagallu") ;
		Vector<EmployeeClass> v = new Vector<EmployeeClass>();
		v .add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(Vector<EmployeeClass> v) {
		// TODO Auto-generated method stub
		for(EmployeeClass e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
		}
	}
	}


