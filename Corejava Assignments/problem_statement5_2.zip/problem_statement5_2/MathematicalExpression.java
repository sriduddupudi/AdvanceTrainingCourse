package com.problem_statement5_2;

	public class MathematicalExpression {
		public static void main(String[] args) {
			
			
			String num= (" 31  -  25  +  (  235  /  20  ) ");
			String[] str=num.split("\s");
			
			for(String str1:str){  
				System.out.println(str1); 
			}
	}
	}

