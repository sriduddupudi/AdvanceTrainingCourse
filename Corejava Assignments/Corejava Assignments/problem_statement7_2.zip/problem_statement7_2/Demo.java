package com.problem_statement7_2;

	class NameNotValidException extends Exception {
		
		private static final long serialVersionUID = 1L;

		public String validname()
	    {
	         return ("Name is not Valid..Please Retype the Name");
	    }
	}


