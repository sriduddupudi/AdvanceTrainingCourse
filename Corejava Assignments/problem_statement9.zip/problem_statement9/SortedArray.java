package com.problem_statement9;

public class SortedArray {
	static void printFreq(int a[], int n)
    {
        int frequency= 1;       
        for (int i = 1; i < n; i++) {
            if (a[i] == a[i - 1]) {
                frequency++;
            }           
            else {
                System.out.println(a[i - 1]+" occurs "+frequency+ " times ");  
                frequency = 1;
            }
        }       
        System.out.println( a[n- 1]+" occurs "+frequency+" times " );
    }
    public static void main(String args[])
    {   
        int arr[]
            = {3,3,3,6,6,4,5,5,7,7,8,8,10};
        int N = arr.length;       
        printFreq(arr, N);
    }
}

